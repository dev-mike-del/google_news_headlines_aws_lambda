aws_url = 'mysql+pymysql://googleHeadlines:googleHeadlines@googleheadlines.cm17zf8vzv2a.us-east-1.rds.amazonaws.com/googleHeadlines'
